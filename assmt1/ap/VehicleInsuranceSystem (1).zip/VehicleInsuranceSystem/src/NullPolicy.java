
public class NullPolicy extends InsurancePolicy {

	public NullPolicy() {
		super(0.0, 0.0);
	}

}
