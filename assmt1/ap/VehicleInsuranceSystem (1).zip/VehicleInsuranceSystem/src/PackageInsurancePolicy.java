
public class PackageInsurancePolicy extends InsurancePolicy {

	public PackageInsurancePolicy () {
		super (0.5, 0.8);
	}

}
