
public class ThirdPartyInsurancePolicy extends InsurancePolicy {

	public ThirdPartyInsurancePolicy() {
		super (0.0, 0.8);
	}

}
