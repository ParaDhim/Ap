
public class FourWheelerEnginePoweredVehicle extends EnginePoweredVehicle {

	public FourWheelerEnginePoweredVehicle (String name) {
		super(name, 4, new PackageInsurancePolicy ());
	}

}