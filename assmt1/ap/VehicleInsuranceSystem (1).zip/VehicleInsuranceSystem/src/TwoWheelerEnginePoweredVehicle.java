
public class TwoWheelerEnginePoweredVehicle extends EnginePoweredVehicle {

	public TwoWheelerEnginePoweredVehicle(String name, InsurancePolicy policy) {
		super(name, 2, policy);
	}

}
